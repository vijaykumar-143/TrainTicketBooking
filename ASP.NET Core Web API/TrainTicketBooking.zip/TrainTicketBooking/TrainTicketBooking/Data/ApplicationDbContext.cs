﻿using TrainTicketBooking.Models.Entities;
using Microsoft.EntityFrameworkCore;
namespace TrainTicketBooking.Data
{
    public class ApplicationDbContext:DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext>options):base(options){ }
        public DbSet<Passenger> Tck {  get; set; }
    }
}
