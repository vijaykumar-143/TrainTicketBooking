﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TrainTicketBooking.Data;
using TrainTicketBooking.Models;
using TrainTicketBooking.Models.Entities;
using Microsoft.EntityFrameworkCore;
using System.Numerics;
namespace TrainTicketBooking.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PassengerController : ControllerBase
    {
        private readonly ApplicationDbContext dbContext;

        public PassengerController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        [HttpGet]
        public IActionResult GetAllEmployees()
        {
            var allEmp = dbContext.Tck.ToList();
            return Ok(allEmp);
        }
        [HttpGet]
        [Route("{TicketNo:guid}")]
        public IActionResult GetByEmployees(Guid TicketNo)
        {
            var allEmp = dbContext.Tck.Find(TicketNo);
            if (allEmp is null)
            {
                return NotFound();
            }
            return Ok(allEmp);
        }
        [HttpPost]
        public IActionResult AddEmployees(NewPassenger add)
        {
            var employee = new Passenger()
            {

                Name = add.Name,
                StartLoaction = add.StartLoaction,
                EndLoaction = add.EndLoaction,
                Phone = add.Phone,
                SeatType = add.SeatType
            };
            dbContext.Tck.Add(employee);
            dbContext.SaveChanges();
            return Ok(employee);
        }
        [HttpPut]
        [Route("{TicketNo:guid}")]
        public IActionResult UpdatePassenger(UpdatePassenger add, Guid TicketNo)
        {
            var employee = dbContext.Tck.Find(TicketNo);
            {
                if (employee is null)
                {
                    return NotFound();
                }

                employee.Name = add.Name;
                employee.StartLoaction = add.StartLoaction;
                employee.EndLoaction = add.EndLoaction;
                employee.Phone = add.Phone;
                employee.SeatType = add.SeatType;
                dbContext.SaveChanges();
                return Ok(employee);
                
            }

        }
        [HttpDelete]
        public IActionResult DeleteByTicketNo(Guid TicketNo)
        {
            var ticket = dbContext.Tck.Find(TicketNo);
            if (ticket is null)
            {
                return NotFound();
            }
            dbContext.Tck.Remove(ticket);
            dbContext.SaveChanges();
            return Ok();
        }
    }
}


