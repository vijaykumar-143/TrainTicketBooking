﻿using System.ComponentModel.DataAnnotations;

namespace TrainTicketBooking.Models
{
    public class NewPassenger
    {
        public required string Name { get; set; }
        [Key]public Guid TicketNo { get; set; }
        public required string StartLoaction { get; set; }
        public required string EndLoaction { get; set; }
        public required string SeatType { get; set; }
        public required string Phone { get; set; }
    }
}
