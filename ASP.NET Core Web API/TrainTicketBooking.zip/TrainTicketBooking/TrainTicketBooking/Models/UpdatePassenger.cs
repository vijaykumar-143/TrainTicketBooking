﻿namespace TrainTicketBooking.Models
{
    public class UpdatePassenger
    {
        public required string Name { get; set; }
        public required string StartLoaction { get; set; }
        public required string EndLoaction { get; set; }
        public required string SeatType { get; set; }
        public required string Phone { get; set; }
    }
}
